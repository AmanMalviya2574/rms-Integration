import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-borrower-home',
  templateUrl: './borrower-home.component.html',
  styleUrls: ['./borrower-home.component.css']
})
export class BorrowerHomeComponent implements OnInit {
  checkCreditScore = false;
  previousCreditScore = false;
  viewLender=false;
  constructor() { }

  ngOnInit() {
  }
  checkCreditScores() {
    this.checkCreditScore = true;
    this.viewLender=false;
    this.previousCreditScore = false;
  }
  previousCreditScores(){
    this.previousCreditScore=true;
    this.viewLender=false;
    this.checkCreditScore=false;
  }
  viewLenders(){
    this.viewLender=true;
    this.previousCreditScore=false;
    this.checkCreditScore=false;

  }
}
