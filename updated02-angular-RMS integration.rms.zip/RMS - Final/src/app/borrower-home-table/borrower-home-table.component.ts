import { Component, OnInit } from '@angular/core';
import { LenderService } from '../service/lender.service';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-borrower-home-table',
  templateUrl: './borrower-home-table.component.html',
  styleUrls: ['./borrower-home-table.component.css']
})
export class BorrowerHomeTableComponent implements OnInit {
  lenders: string[];
  constructor(private lenderService: LenderService, private router: Router) { }

  ngOnInit() {
    this.lenderService.getLenders().subscribe(
      response => this.handleSuccessfulResponse(response)
     
    );

  }
  handleSuccessfulResponse(response) {
    this.lenders = response;
   
  }
  routeWithData(lender) {
    //console.log("value of lender"+lender.userId)
    this.router.navigate(['/credit-application'], {queryParams:{lender: lender.userId}});
  }
}
