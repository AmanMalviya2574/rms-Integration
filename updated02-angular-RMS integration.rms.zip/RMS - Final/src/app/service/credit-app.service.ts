
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CreditApp } from 'src/model/credit-app';

@Injectable({
  providedIn: 'root'
})
export class CreditAppService {
  private submitUrl:string;


  constructor(private http: HttpClient) {
    this.submitUrl='http://localhost:8080/rms/submitcreditappform?id=1101';

   }
  public save(creditApp:CreditApp){
    console.log("aman: ",creditApp);
    return this.http.post<CreditApp>(this.submitUrl,creditApp);
  }
}
