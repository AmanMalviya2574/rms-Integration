import { Lender } from 'src/model/lender';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Policy } from 'src/model/policy';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  lender:Lender;
    
  constructor(private httpClient: HttpClient) {
    this.lender = new Lender();
   }

  getPolicies(userId){
    this.lender.userId=userId;
    return this.httpClient.post<Policy[]>('http://localhost:8080/rms/lender/policies',this.lender);
  }
}
