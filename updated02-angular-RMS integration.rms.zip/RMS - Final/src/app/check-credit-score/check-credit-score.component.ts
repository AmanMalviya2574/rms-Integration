import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-credit-score',
  templateUrl: './check-credit-score.component.html',
  styleUrls: ['./check-credit-score.component.css']
})
export class CheckCreditScoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
