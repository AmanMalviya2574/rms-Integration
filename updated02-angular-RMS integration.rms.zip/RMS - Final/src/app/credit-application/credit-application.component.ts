import { PolicyResponse } from './../../model/policy-response';
import { CreditAppService } from './../service/credit-app.service';

import { BorrowerHomeComponent } from './../borrower-home/borrower-home.component';
import { PolicyService } from './../service/policy.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { Borrower } from 'src/model/borrower';
import { CreditApp } from 'src/model/credit-app';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-credit-application',
  templateUrl: './credit-application.component.html',
  styleUrls: ['./credit-application.component.css']
})
export class CreditApplicationComponent implements OnInit {
  policies: string[];
  userId;
  creditApp: CreditApp;
  creditAppForm: FormGroup;
  policyJson = [];
  public formLabel: any = [];
  policyResponse: [];
  constructor(private policyService: PolicyService, private routers: Router, private creditAppService: CreditAppService, private router: ActivatedRoute,
    private formBuilder: FormBuilder) {
    this.creditApp = new CreditApp();
  }
  ngOnInit() {
    console.log(this.router);
    this.creditAppForm = this.formBuilder.group({
      cmpName: ['', Validators.required],
      policyName: ['', Validators.required]
    });
    this.userId = this.router.queryParams['getValue']()['lender'];

    this.policyService.getPolicies(this.userId).subscribe(response => this.handle(response));



  }
  handle(response) {
    this.policies = response;
    this.formatData(this.policies);
  }

  formatData(policies) {
    console.log("Policies", this.policies)


    // for (var i in this.policies) {
    //   let json = {};
    //   /*  json["policyName"]="";
    //    this.policyJson.push(json);
    //    debugger;
    //    console.log(this.policyJson); */

    //   const policyId = this.policies[i]["policyId"]
    //   const policyValue = this.policies[i][""]
    //   json[policyId] = ''
    //   this.policyJson.push(json);

    // }
    // console.log("Policy Json", this.policyJson);

  }
  editvalue(index, event, key) {
    let value = event.target.value;
    this.formLabel[key] = value;
    this.formLabel;
    //console.log("formLabel ", this.formLabel);
    // this.policyJson[key]=value;
    // this.policyJson[index]=value;
    // debugger;
  }
  onSubmit() {
    this.policyResponse = this.formLabel;
    
    console.log("policy Response ", this.policyResponse);
    this.creditApp.policyValues=this.policyResponse;
    this.creditApp.lenderId = this.userId;
    console.log("fgdfgdf",this.creditApp.policyValues)
    for (var i in this.creditApp.policyValues) {     let json = {};
    
    
    const policyId = i;
    const policyValue = this.creditApp.policyValues[i];
    
    this.policyJson.push({"policyId":policyId,
  "policyValue":policyValue});
    
  }
  //this.creditApp.policyValues = this.policyJson;
  this.creditApp.policyValues=this.policyJson;
  console.log("Policy Json", this.policyJson);
    
    console.log("policy Response ", this.creditApp);

    this.creditAppService.save(this.creditApp).subscribe();
    //console.log("policy Response :", this.policyResponse[1]);
    // if (this.creditAppForm.invalid) {
    //   return;

  }

}

  // get f() { return this.creditAppForm.controls; }

  // trackByIndex(index:number,obj:any):any{
  //   return index;
  // }  


