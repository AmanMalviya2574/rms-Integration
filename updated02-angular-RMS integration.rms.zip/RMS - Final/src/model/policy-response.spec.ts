import { PolicyResponse } from './policy-response';

describe('PolicyResponse', () => {
  it('should create an instance', () => {
    expect(new PolicyResponse()).toBeTruthy();
  });
});
