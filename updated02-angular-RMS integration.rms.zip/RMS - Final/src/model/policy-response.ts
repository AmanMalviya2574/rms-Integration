export class PolicyResponse {
    policyId: number;
    policyValue: string;
}
