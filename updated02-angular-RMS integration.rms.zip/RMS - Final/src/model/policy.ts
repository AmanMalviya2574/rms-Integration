export class Policy {

    policyName: string;
}
