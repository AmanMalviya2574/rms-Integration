import { CreditApp } from './credit-app';

describe('CreditApp', () => {
  it('should create an instance', () => {
    expect(new CreditApp()).toBeTruthy();
  });
});
