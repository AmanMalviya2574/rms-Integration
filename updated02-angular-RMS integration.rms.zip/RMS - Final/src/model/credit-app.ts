import { PolicyResponse } from './policy-response';

export class CreditApp {
    companyName: string;
    lenderId: number;
    policyValues:PolicyResponse[];

}
