import { Component} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BorrowerService } from 'src/app/service/borrower.service';
import { Borrower } from 'src/model/borrower';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent {

  borrower:Borrower;

  constructor(private route: ActivatedRoute, private router:Router,private borrowerService:BorrowerService) {
    this.borrower= new Borrower();
  }

  onSubmit(){
  
    this.borrowerService.save(this.borrower).subscribe();
  }

}
