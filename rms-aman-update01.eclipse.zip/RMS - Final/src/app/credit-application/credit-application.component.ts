import { CreditAppService } from './../service/credit-app.service';

import { BorrowerHomeComponent } from './../borrower-home/borrower-home.component';
import { PolicyService } from './../service/policy.service';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import { Borrower } from 'src/model/borrower';
import { CreditApp } from 'src/model/credit-app';

@Component({
  selector: 'app-credit-application',
  templateUrl: './credit-application.component.html',
  styleUrls: ['./credit-application.component.css']
})
export class CreditApplicationComponent implements OnInit {
policies : string[];
userId;
creditApp:CreditApp;
constructor(private policyService:PolicyService,private router: ActivatedRoute, private creditAppService:CreditAppService) 
  {
    this.creditApp=new CreditApp();
  }
  ngOnInit() {
    console.log(this.router);
    this.userId = this.router.queryParams['getValue']()['lender'];
  
    
    // subscribe( params => {
    //   debugger ;
    //   console.log("params value"+params) 
    // });
   
    // var userid= this.router.getCurrentNavigation();
    //this.router.lastSuccessfulNavigation.extras;
    this.policyService.getPolicies(this.userId).subscribe(response=>this.handle(response));
  }
  handle(response){
    this.policies=response;
  }
  onSubmit(){
    this.creditAppService.save(this.creditApp).subscribe();
  }

}
