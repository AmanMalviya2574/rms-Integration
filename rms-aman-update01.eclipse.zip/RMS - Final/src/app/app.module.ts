import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LenderHomeComponent } from './lender/lender-home/lender-home.component';
import { Routes,RouterModule } from '@angular/router';
import { AddPolicyComponent } from './lender/add-policy/add-policy.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { LogoutComponent } from './logout/logout.component';
import { ForgotPasswordComponent } from './login-form/forgot-password/forgot-password.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';

import { AuthenticationService } from './login-form/authentication.service';
import { AuthguardService } from './login-form/authguard.service';


import { AppHomeComponent } from './app-home/app-home.component';
import { LenderFormComponent } from './register/lender-form/lender-form.component';
import { UserFormComponent } from './register/user-form/user-form.component';
import { LenderService } from './service/lender.service';
import { BorrowerService } from './service/borrower.service';
import { HttpClientModule } from '@angular/common/http';
import { BorrowerHomeTableComponent } from './borrower-home-table/borrower-home-table.component';
import { BorrowerHomeComponent } from './borrower-home/borrower-home.component';
import { HeaderComponent } from './header/header.component';
import { CreditApplicationComponent } from './credit-application/credit-application.component';


const appRoutes:Routes = [
  {
    path : '',
    component : AppHomeComponent
    },
  {
  path : 'login',
  component : LoginFormComponent
  },
  {
  path : 'forgotpassword',
  component : ForgotPasswordComponent
  },
  {
    path : 'admin-home',
    component : AdminHomeComponent,
    canActivate:[AuthguardService]
  },
 {
    path : 'logout',
    component : LogoutComponent,
   canActivate:[AuthguardService]
  },
  {
    path:'lender-home',
    component : LenderHomeComponent,
    canActivate:[AuthguardService]
    },
    {
      path:'add-policy',
      component:AddPolicyComponent
    },
    {
      path:'register-selection',
      component:RegisterComponent
    }, 
    {
      path:'lender-registration',
      component:LenderFormComponent
    } ,
    {
      path:'borrower-registration',
      component:UserFormComponent
    },
    {
      path:'borrower-home',
      component:BorrowerHomeComponent
    },
    {
      path:'borrower-home-table',
      component:BorrowerHomeTableComponent
    },
    {
      path:'credit-application',
      component:CreditApplicationComponent
    }
    

]




@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LenderHomeComponent,
    AddPolicyComponent,
    LoginFormComponent,
    LogoutComponent,
    ForgotPasswordComponent,
    AdminHomeComponent,
    AppHomeComponent,
    LenderFormComponent,
    UserFormComponent,
    BorrowerHomeTableComponent,
    BorrowerHomeComponent,
    HeaderComponent,
    CreditApplicationComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [AuthenticationService,AuthguardService, LenderService, BorrowerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
