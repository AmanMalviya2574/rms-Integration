import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Lender } from 'src/model/lender';

@Injectable({
  providedIn: 'root'
})
export class LenderService {

  private registerUrl:string;
  private getlenderUrl : string;
  constructor(private http: HttpClient) {
    this.registerUrl='http://localhost:8080/rms/lender/registerlender';
    this.getlenderUrl='http://localhost:8080/rms/lender/ActiveLenders';
  }

  public save(lender:Lender){
    return this.http.post<Lender>(this.registerUrl,lender);
  }
  getLenders()
  {
    return this.http.get<Lender[]>(this.getlenderUrl);
  }
}