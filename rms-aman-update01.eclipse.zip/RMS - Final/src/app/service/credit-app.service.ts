import { CreditApp } from './../../model/credit-app';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CreditAppService {
  private submitUrl:string;


  constructor(private http: HttpClient) {
    this.submitUrl='http://localhost:8080/rms/submitcreditappform';

   }
  public save(creditApp:CreditApp){
    return this.http.post<CreditApp>(this.submitUrl,creditApp);
  }
}
