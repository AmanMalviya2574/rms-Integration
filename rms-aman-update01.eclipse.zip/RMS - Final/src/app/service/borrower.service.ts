import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Borrower } from 'src/model/borrower';

@Injectable({
  providedIn: 'root'
})
export class BorrowerService {

  private registerUrl:string;
  constructor(private http: HttpClient) {
    this.registerUrl='http://localhost:8080/rms/registerborrower';
  }

  public save(borrower:Borrower){
    return this.http.post<Borrower>(this.registerUrl,borrower);
  }
}
