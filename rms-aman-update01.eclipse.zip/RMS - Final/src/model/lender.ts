export class Lender {
    userId:number;
    userName: string;
    userEmail: string;
    userPassword:string;
    tenureRange:string;
    loanInterest:string;
    lenderDescription:string;
    loanAmountRange:string;
}