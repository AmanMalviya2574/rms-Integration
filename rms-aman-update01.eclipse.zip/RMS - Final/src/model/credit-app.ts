export class CreditApp {
    companyName: string;
}
