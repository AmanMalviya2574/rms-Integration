package com.casestudy.rms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.model.Lender;
import com.casestudy.rms.service.IAdminService;



@RestController
@RequestMapping("/rms")
@CrossOrigin(origins = {"http://localhost:4200"})
public class AdminController {
 
    @Autowired
    IAdminService adminService;
    
    @GetMapping("viewLenders/PendingLenders")
    public ResponseEntity<List<Lender>> getPendingLenders(){
        List<Lender> lst = adminService.getPendingLenders();
        return new ResponseEntity<List<Lender>>(lst,HttpStatus.OK);
    }
    
    @GetMapping("viewLenders/ActiveLenders")
    public ResponseEntity<List<Lender>> getActiveLenders(){
        List<Lender> lst = adminService.getPendingLenders();
        return new ResponseEntity<List<Lender>>(lst,HttpStatus.OK);
    }
    
    @GetMapping("viewLenders/InactiveLenders")
    public ResponseEntity<List<Lender>> getInactiveLenders(){
        List<Lender> lst = adminService.getPendingLenders();
        return new ResponseEntity<List<Lender>>(lst,HttpStatus.OK);
    }

}
