package com.casestudy.rms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Driver Class.
 * @author impetus
 *
 */
@SpringBootApplication
public class RmsApplication {

    /**
     * Main method.
     * @param args - arguments
     */
	public static void main(String[] args) {
		SpringApplication.run(RmsApplication.class, args);
	}

}
