package com.casestudy.rms.service;

import com.casestudy.rms.model.CreditApplication;

public interface ICreditAppService {

  boolean submitCreditAppForm(CreditApplication creditApp);




}
