package com.casestudy.rms.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POLICY")
public class Policy{
  
  @Id
  @Column(name = "POLICY_ID")
  private int policyId;
  
  @Column(name = "POLICY_NAME")
  private String policyName;
  
  @Column(name = "LENDER_ID")
  public int addedBy;
  
  @Column(name = "CREATION_DATE")
  private LocalDateTime creationDate;
  
  @Column(name = "MODIFICATION_DATE")
  private LocalDateTime modificationDate;

  public int getPolicyId() {
    return policyId;
  }

  public void setPolicyId(int policyId) {
    this.policyId = policyId;
  }

  public String getPolicyName() {
    return policyName;
  }

  public void setPolicyName(String policyName) {
    this.policyName = policyName;
  }

  

  public int getAddedBy() {
    return addedBy;
  }

  public void setAddedBy(int addedBy) {
    this.addedBy = addedBy;
  }

  public LocalDateTime getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(LocalDateTime creationDate) {
    this.creationDate = creationDate;
  }

  public LocalDateTime getModificationDate() {
    return modificationDate;
  }

  public void setModificationDate(LocalDateTime modificationDate) {
    this.modificationDate = modificationDate;
  }

  

}
