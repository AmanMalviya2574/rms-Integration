package com.casestudy.rms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;
import com.casestudy.rms.model.Policy;
import com.casestudy.rms.service.ILenderService;
import com.casestudy.rms.service.IPolicyService;



@RestController
@RequestMapping("/rms/lender")
@CrossOrigin(origins = {"http://localhost:4200"})
public class LenderController {
    
    @Autowired
    private ILenderService lenderService;
    @Autowired
    private IPolicyService policyService;
    
    @RequestMapping(value="/registerlender", consumes="application/JSON", method=RequestMethod.POST)
    public ResponseEntity<Void> registerLender(@RequestBody Lender lender){
        boolean flag = lenderService.registerLender(lender);
        if (flag == false) {
             return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
        else {
            return new ResponseEntity<Void>(HttpStatus.CREATED);
        }
    }
    
   
    
    @RequestMapping(value="/addFinancialAnalyst", consumes="application/JSON", method=RequestMethod.POST)
    public ResponseEntity<Void> addFinancialAnalyst(@RequestBody FinancialAnalyst financialAnalyst, @RequestParam("id") int id){
        Lender lender = lenderService.getLender(id); 
        boolean flag = lenderService.addFinancialAnalyst(financialAnalyst,lender);
        if (flag == false) {
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
       }
       else {
           return new ResponseEntity<Void>(HttpStatus.CREATED);
       }
        
    }
    
    @GetMapping("/ActiveLenders")
    public ResponseEntity<List<Lender>> getActiveLenders(){
        List<Lender> lst = lenderService.getActiveLenders();
        return new ResponseEntity<List<Lender>>(lst,HttpStatus.OK);
        
    }
    @PostMapping("/policies")
    public ResponseEntity<List<Policy>> getPolicies(@RequestBody Lender lender){
        List<Policy> lst = policyService.getPolicies(lender.getUserId());
        return new ResponseEntity<List<Policy>>(lst,HttpStatus.OK);
        
    }
    

}
