package com.casestudy.rms.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.CreditAppDAO;
import com.casestudy.rms.model.CreditApplication;
import com.casestudy.rms.util.ApplicationConstant;

@Service
public class CreditAppService implements ICreditAppService {
  @Autowired
  private CreditAppDAO creditAppDAO;

  @Override
  public boolean submitCreditAppForm(CreditApplication creditApp) {

    creditApp.setCreditScore(ApplicationConstant.INITIAL_CREDIT_SCORE);
    creditApp.setApplicationStatus(ApplicationConstant.STATUS_HOLD);
    creditApp.setCompanyName(creditApp.getCompanyName());
    creditApp.setCreationDate(LocalDateTime.now());
    creditApp.setModificationDate(LocalDateTime.now());
    creditApp.setBorrowerId(7102);
    creditApp.setLenderId(2101);
    creditApp.setFinancialAnalystId(7101);

    creditAppDAO.submitCreditAppForm(creditApp);
    return true;
  }
}
