package com.casestudy.rms.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;

@Transactional
@Repository
public class LenderDAO implements ILenderDAO {

    @PersistenceContext 
    private EntityManager entityManager;
    
    
    @Override
    public void registerLender(Lender lender) {
        
        entityManager.persist(lender);
        
    }

    @Override
    public boolean lenderExists(Lender lender) {
        String hql="FROM User WHERE userEmail = ?1";
        int count = entityManager.createQuery(hql).setParameter(1,lender.getUserEmail()).getResultList().size();
        return count>0 ? true:false;
    }

   
    @Override
    public void addFinancialAnalyst(FinancialAnalyst financialAnalyst) {
        entityManager.persist(financialAnalyst);
        
    }

    @Override
    public Lender getLender(int lenderId) {
        
        return entityManager.find(Lender.class, lenderId);
    }
    @Override
    public List<Lender> getLenderWithStatus(int status) {
        String hql = "FROM User where userAIStatus = ?1 AND userRole= ?2"; 
       return (List<Lender>)entityManager.createQuery(hql).setParameter(1,status).setParameter(2,"ROLE_LENDER").getResultList();
    }

}
