package com.casestudy.rms.dao;

import com.casestudy.rms.model.User;

/** Declares method for User DAO.
 * 
 * @author impetus */
public interface IUserDAO {

    /** Register a Borrower.
     * 
     * @param user
     *            - User */
    void registerBorrower(User user);

    /** Checks Borrower exists or not.
     * 
     * @param user
     *            - Borrower
     * @return - Exists or not */
    boolean userExists(User user);

}
