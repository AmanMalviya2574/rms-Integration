package com.casestudy.rms.dto;

public class CreditPolicyMappingDTO {
  private String companyName;
  private int borrowerId;
  private int lenderId;
  
  public String getCompanyName() {
    return companyName;
  }
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  public int getBorrowerId() {
    return borrowerId;
  }
  public void setBorrowerId(int borrowerId) {
    this.borrowerId = borrowerId;
  }
  public int getLenderId() {
    return lenderId;
  }
  public void setLenderId(int lenderId) {
    this.lenderId = lenderId;
  }
  
}
