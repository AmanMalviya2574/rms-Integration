package com.casestudy.rms.dto;

public class PolicyValues {
  
  private int policyId;
  private String policyValue;
  public int getPolicyId() {
    return policyId;
  }
  public void setPolicyId(int policyId) {
    this.policyId = policyId;
  }
  public String getPolicyValue() {
    return policyValue;
  }
  public void setPolicyValue(String policyValue) {
    this.policyValue = policyValue;
  }
  @Override
  public String toString() {
    return "PolicyValues [policyId=" + policyId + ", policyValue=" + policyValue + "]";
  }
  
  

}
