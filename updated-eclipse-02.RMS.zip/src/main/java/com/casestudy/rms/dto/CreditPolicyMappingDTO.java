package com.casestudy.rms.dto;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class CreditPolicyMappingDTO {
  private String companyName;
  private int borrowerId;
  private int lenderId;
  private List<Map<String, String>> policyValues;

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public int getBorrowerId() {
    return borrowerId;
  }

  public void setBorrowerId(int borrowerId) {
    this.borrowerId = borrowerId;
  }

  public int getLenderId() {
    return lenderId;
  }

  public void setLenderId(int lenderId) {
    this.lenderId = lenderId;
  }

  public List<Map<String, String>> getPolicyValues() {
    return policyValues;
  }

  public void setPolicyValues(List<Map<String, String>> policyValues) {
    this.policyValues = policyValues;
  }

  @Override
  public String toString() {
    return "CreditPolicyMappingDTO [companyName=" + companyName + ", borrowerId=" + borrowerId + ", lenderId=" + lenderId + ", policyValues="
        + policyValues + "]";
  }

  /*
   * public PolicyValues[] getPolicyValue() { return policyValues; } public void setPolicyValue(PolicyValues[] policyValues) { this.policyValues =
   * policyValues; }
   */

  

}
