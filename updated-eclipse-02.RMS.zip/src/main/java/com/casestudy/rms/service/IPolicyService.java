package com.casestudy.rms.service;

import java.util.List;

import com.casestudy.rms.model.Policy;

public interface IPolicyService {
  List<Policy> getPolicies(int userID);

}
