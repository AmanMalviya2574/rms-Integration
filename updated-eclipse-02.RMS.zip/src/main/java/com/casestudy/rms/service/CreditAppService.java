package com.casestudy.rms.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.CreditAppDAO;
import com.casestudy.rms.dao.MappingCreditAppPolicyDAO;
import com.casestudy.rms.dto.CreditPolicyMappingDTO;
import com.casestudy.rms.dto.PolicyValues;
import com.casestudy.rms.model.CreditApplication;
import com.casestudy.rms.model.MappingCreditAppPolicy;

import com.casestudy.rms.util.ApplicationConstant;

@Service
public class CreditAppService implements ICreditAppService {
  @Autowired
  private CreditAppDAO creditAppDAO;
  
  @Autowired
  private MappingCreditAppPolicyDAO mappingCreditAppPolicyDAO;

  @Override
  public boolean submitCreditAppForm(CreditPolicyMappingDTO creditApplication,int borrowerId) {
    

    


    

    CreditApplication creditApp = new  CreditApplication();
    creditApp.setCreditScore(ApplicationConstant.INITIAL_CREDIT_SCORE);
    creditApp.setApplicationStatus(ApplicationConstant.STATUS_HOLD);
    creditApp.setCompanyName(creditApplication.getCompanyName());
    creditApp.setCreationDate(LocalDateTime.now());
    creditApp.setModificationDate(LocalDateTime.now());
    creditApp.setBorrowerId(borrowerId);
    creditApp.setLenderId(creditApplication.getLenderId());
    creditApp.setFinancialAnalystId(0);
    creditAppDAO.submitCreditAppForm(creditApp);
    int maxId = creditAppDAO.getMaxApplicationIdId();
    List<Map<String, String>> pv = creditApplication.getPolicyValues();

    for(int i=0;i<pv.size();i++)
    {
      MappingCreditAppPolicy mappingCreditAppPolicy = new MappingCreditAppPolicy();
      mappingCreditAppPolicy.setPolicyId(Integer.parseInt(creditApplication.getPolicyValues().get(i).get("policyId")));
      mappingCreditAppPolicy.setPolicyValue(creditApplication.getPolicyValues().get(i).get("policyValue"));
      mappingCreditAppPolicy.setApplicationId(maxId);
      System.out.println("latest ap[plication id"+mappingCreditAppPolicy.getApplicationId());
      mappingCreditAppPolicyDAO.submitFormValue(mappingCreditAppPolicy);
    }
    

    
    return true;
  }
}
