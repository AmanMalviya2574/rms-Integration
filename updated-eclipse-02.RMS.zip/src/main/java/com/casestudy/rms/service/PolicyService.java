package com.casestudy.rms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IPolicyDAO;
import com.casestudy.rms.model.Policy;
@Service
public class PolicyService implements IPolicyService {
  @Autowired
  private IPolicyDAO policyDAO;

  @Override
  public List<Policy> getPolicies(int userID) {

    return policyDAO.getPolicy(userID);
  }

}
