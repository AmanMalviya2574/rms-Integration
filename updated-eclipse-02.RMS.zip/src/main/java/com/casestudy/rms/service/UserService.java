package com.casestudy.rms.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IUserDAO;
import com.casestudy.rms.model.User;
import com.casestudy.rms.util.ApplicationConstant;

/** Provides services to User.
 * 
 * @author impetus */
@Service
public class UserService implements IUserService {

    @Autowired
    private IUserDAO userDAO;

    @Override
    public boolean registerBorrower(User user) {

        if (userDAO.userExists(user)){
            return false;
        }else {
            user.setUserAIStatus(ApplicationConstant.ACTIVE);
            user.setUserRole("ROLE_BORROWER");
            user.setCreationDate(LocalDateTime.now());
            user.setModificationDate(LocalDateTime.now());
            userDAO.registerBorrower(user);
            return true;
        }
    }

}
