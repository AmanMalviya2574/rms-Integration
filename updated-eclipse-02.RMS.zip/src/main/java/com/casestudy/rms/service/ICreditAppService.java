package com.casestudy.rms.service;

import com.casestudy.rms.dto.CreditPolicyMappingDTO;
import com.casestudy.rms.model.CreditApplication;
import com.casestudy.rms.model.User;

public interface ICreditAppService {

  boolean submitCreditAppForm(CreditPolicyMappingDTO creditApp, int borrowerId);




}
