package com.casestudy.rms.model;

//
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CREDIT_APPLICATION")
public class CreditApplication {
  @Id
  @Column(name = "APPLICATION_ID")
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int applicationId;

  @Column(name = "CREDIT_SCORE")
  private int creditScore;

  @Column(name = "APPLICATION_STATUS")
  private int applicationStatus;

  @Column(name = "COMPANY_NAME")
  private String companyName;

  @Column(name = "CREATION_DATE")
  private LocalDateTime creationDate;

  @Column(name = "MODIFICATION_DATE")
  private LocalDateTime modificationDate;

 

  @Column(name = "BORROWER_ID")
  private int borrowerId;
  
  @Column(name="FINANCIAL_ANALYST_ID")
  private int financialAnalystId;

  @Column(name = "LENDER_ID")
  private int lenderId;

  public int getBorrowerId() {
    return borrowerId;
  }

  public void setBorrowerId(int borrowerId) {
    this.borrowerId = borrowerId;
  }

  public int getLenderId() {
    return lenderId;
  }

  public void setLenderId(int lenderId) {
    this.lenderId = lenderId;
  }


  public int getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(int applicationId) {
    this.applicationId = applicationId;
  }

  public int getCreditScore() {
    return creditScore;
  }

  public void setCreditScore(int creditScore) {
    this.creditScore = creditScore;
  }

  public int getApplicationStatus() {
    return applicationStatus;
  }

  public void setApplicationStatus(int applicationStatus) {
    this.applicationStatus = applicationStatus;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public LocalDateTime getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(LocalDateTime creationDate) {
    this.creationDate = creationDate;
  }

  public LocalDateTime getModificationDate() {
    return modificationDate;
  }

  public void setModificationDate(LocalDateTime modificationDate) {
    this.modificationDate = modificationDate;
  }
  public int getFinancialAnalystId() {
    return financialAnalystId;
  }

  public void setFinancialAnalystId(int financialAnalystId) {
    this.financialAnalystId = financialAnalystId;
  }
}
