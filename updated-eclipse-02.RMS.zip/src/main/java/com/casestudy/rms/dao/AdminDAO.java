package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.Lender;

/**
 * Represents Administrator DAO.
 * @author impetus
 *
 */
@Transactional
@Repository
public class AdminDAO implements IAdminDAO {

    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public List<Lender> getLenderWithStatus(int status) {
        String hql = "FROM User where userStatus = ?1 AND userRole= ?2";
        
       return (List<Lender>)entityManager.createQuery(hql).setParameter(1,status).setParameter(2,"ROLE_LENDER").getResultList();
    }

}
