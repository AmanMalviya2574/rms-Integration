package com.casestudy.rms.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.Policy;

@Transactional
@Repository
public class PolicyDAO implements IPolicyDAO {
  
  @PersistenceContext
  private EntityManager entityManager;

  @Override
  public List<Policy> getPolicy(int userID) {
    String hql = "FROM Policy where addedBy=?1 OR addedBy=?2";
    return (List<Policy>)entityManager.createQuery(hql).setParameter(1,userID).setParameter(2, 0).getResultList();
  }
}
