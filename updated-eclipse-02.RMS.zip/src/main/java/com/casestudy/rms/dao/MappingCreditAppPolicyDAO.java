package com.casestudy.rms.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.MappingCreditAppPolicy;

@Repository
public class MappingCreditAppPolicyDAO  implements IMappingCreditAppPolicyDAO{

  @PersistenceContext
  private EntityManager entityManager;

  @Transactional
  @Override
  public void submitFormValue(MappingCreditAppPolicy mappingCreditAppPolicy) {
    entityManager.persist(mappingCreditAppPolicy);
    entityManager.close();
  }

}
