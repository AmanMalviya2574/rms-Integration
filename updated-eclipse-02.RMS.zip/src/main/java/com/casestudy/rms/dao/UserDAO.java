package com.casestudy.rms.dao;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.User;

@Transactional
@Repository
public class UserDAO implements IUserDAO {
	
	@PersistenceContext	
	private EntityManager entityManager;
	
	
	@Override
	public void registerBorrower(User user) {
		entityManager.persist(user);
	}

	@Override
	public boolean userExists(User user) {
		
		String hql="FROM User WHERE userEmail = ?1";
		int count = entityManager.createQuery(hql).setParameter(1,user.getUserEmail()).getResultList().size();
		return count>0 ? true:false;
	}

}
