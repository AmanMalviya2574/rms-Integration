package com.casestudy.rms.dao;

import java.util.List;

import com.casestudy.rms.model.Lender;
import com.casestudy.rms.model.Policy;

public interface IPolicyDAO {
  List<Policy> getPolicy(int userId);
  
}

