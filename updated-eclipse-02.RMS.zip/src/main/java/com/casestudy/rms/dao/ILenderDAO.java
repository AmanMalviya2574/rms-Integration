package com.casestudy.rms.dao;

import java.util.List;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;

/** Declares method for Lender DAO.
 * 
 * @author impetus */
public interface ILenderDAO {
    /** Register a Lender.
     * 
     * @param lender
     *            - Lender */
    void registerLender(Lender lender);

    /** Checks Lender exists or not.
     * 
     * @param lender
     *            - Lender
     * @return Exists or not */
    boolean lenderExists(Lender lender);

    /** Add financial Analyst corresponding to Lender.
     * 
     * @param financialAnalyst
     *            - Financial Analyst */
    void addFinancialAnalyst(FinancialAnalyst financialAnalyst);

    /** Gets Lender according to Lender ID.
     * 
     * @param lenderId
     *            - Lender ID
     * @return Lender */
    
    Lender getLender(int lenderId);
    List<Lender> getLenderWithStatus(int status);
    

}
