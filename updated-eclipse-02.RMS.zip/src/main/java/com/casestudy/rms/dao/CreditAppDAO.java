package com.casestudy.rms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.CreditApplication;


@Transactional
@Repository
public class CreditAppDAO implements ICreditAppDAO{

  @PersistenceContext
  private EntityManager entityManager;
  
  @Override
  public void submitCreditAppForm(CreditApplication creditApp) {
    entityManager.persist(creditApp);
  }
  
  @Override
  public int getMaxApplicationIdId() {
      String hql = "SELECT MAX(applicationId) FROM CreditApplication";
      return (int) entityManager.createQuery(hql).getResultList().get(0);
  }

//  public boolean borrowerExists(CreditApplication creditApp) {
//    return false;
//  }
}
