package com.casestudy.rms.dao;

import com.casestudy.rms.model.CreditApplication;

public interface ICreditAppDAO {
  void submitCreditAppForm(CreditApplication creditApp);
  int getMaxApplicationIdId();
}
